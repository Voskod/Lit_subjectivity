import sys
import pickle
import json
import random
import os
import csv
import time
import re
import cogact_arch as cog
from cogact_arch import CogAct, Node, Link, Modality, Stm #import namespace for pickle to work!!!!

#solution to windows problem "pickle esxceeded recursion depth"
sys.setrecursionlimit(10000)

train_folder = 'lit_exp/participant A/lit_train'
test_folder = 'lit_exp/participant A/lit_predict'
pickle_save = 'CogAct_pA2.pickle'
#train_folder = 'lit_test/train_texts'
#test_folder = 'lit_test/predict_texts_60'



#LOAD TREE STATE
#with open(pickle_save, 'rb') as f:  #rb - read binary
    #cogact = pickle.load(f)

# # TESTS ====================================================

# In[ ]:





# # Music and Literature TRAINING ================================================

# In[12]:


sep_sent = '\.|!|\?|\.\.\.|…'
sep_phrases = '\.|!|\?|\.\.\.|…|,|:|;|-|—|"|\'|&'
sep_number = 20


# In[13]:


def get_literature_patterns(text, separator, split_by_letters=None):
    patterns=[]
    if isinstance(separator, int):
        words = [word for word in re.split('[^a-zа-я0-9]+', text.lower())]
        for i in range(0, len(words), separator):
            patterns.append(words[i:i+separator] +['$'])
    return patterns


# In[14]:


def get_sentences(text, sep, min_len=3): #number of words?
    patterns = []
    
    if isinstance(sep, int): #take sep_number words otherwise split by punctuation
        words = [word for word in re.split('[^a-zа-я0-9]+', text.lower())] # if len(word) >= 3] #option to remove short words
        for i in range(0, len(words), sep):
            patterns.append(words[i:i + sep] + ['$'])
    else:
        for sent in re.split(sep, text.lower()):
            sent = list(filter(lambda word : len(word) >= 3, re.split('[^a-zа-я0-9]+', sent)))
            if len(sent) >= min_len:
                patterns.append(sent + ['$'])
    return patterns

#(\r\n){2,}[^\r\n]*(\r\n){2,} -> \r\n\r\n\r\n #clean poetry text from titles and one line rubbish in Notepad+
# In[24]:


def train(folder, get_patterns=None): #Same as above, easier interface for multiple categories
    inp = []

    for label in os.listdir(folder):
        p = os.path.join(folder, label)
        if os.path.isdir(p):
            for file in os.listdir(p):
                file = os.path.join(p, file)
                with open(file, 'r',  encoding='utf-8', errors='ignore') as f:
                    patterns = get_patterns(f.read())
                inp += list(zip((list(p) for p in patterns), [[*label, '$']] * len(patterns)))
                #print('inp', inp)
    
    random.shuffle(inp) #shuffle input patterns
    cogact = cog.CogAct() #comment out to learn on top of previous knowledge, uncomment to train from blank slate
    train_cycles = 300
    for i in range(train_cycles): #default 300
        errors = 0
        if i%10==0:
            print(i, '/', train_cycles)
        i = 0
        n = len(inp)
        for pattern in inp:
            # print('handle pattern', i, '/', n)
            i += 1
            vis, verb = pattern
            t = cogact.clock
            node1 = cogact.visual.recognise_and_learn(vis)
            node2 = cogact.verbal.recognise_and_learn(verb)
            if cogact.clock != t:
                errors += 1
                continue
            node1.label = node2.idx
            node2.label = node1.idx
        if errors == 0:
            break
    return cogact


# In[ ]:





# In[25]:


#folder = 'testing2023/txt_simple/train_texts'
#folder = 'lit_test/train_texts'
folder = 'lit_exp/participant A/lit_train'
get_pats = lambda text: get_sentences(text, sep_number)

input_test = []
for label in os.listdir(folder):
    p = os.path.join(folder, label)
#     print(p, os.path.isdir(p))
    
    if os.path.isdir(p):
            for file in os.listdir(p):
                file = os.path.join(p, file)
                with open(file, 'r',  encoding='utf-8', errors='ignore') as f:
                    patterns = get_pats(f.read())
                input_test += list(zip((list(p) for p in patterns), [[*label, '$']] * len(patterns)))
#print('input_test=', input_test[:2],'\n')




start = time.time()
def train_poets(folder, sep): #categorise WITHOUT using similarity links
    return train(folder, lambda text: get_sentences(text, sep))

cogact = train_poets(train_folder, sep_number)
end = time.time()
print('Time taken=', end - start)


# In[ ]:



print( 'number of nodes=', len(cogact.nodes) )#NUMBER of NODES  IN CogAct


#====================TESTING+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def cat_file(file, get_patterns, correct_label):
    with open(file, 'r', errors='ignore') as f:
        tests = get_patterns(f.read())

    print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
    print('--', file, '\n')
    print('-------- MAX IMAGE METHOD -------------------------------------\n')
    t_start = time.time()
    labels = {}
    for test in tests:
        max_image = []
        label = None
        for offset in range(len(test) - 1):
            node = cogact.visual.recognise(test[offset:])
            if node.label is not None and len(node.image) > len(max_image):
                max_image = node.image
                # label = cogact.nodes[node.label].image
                labels[node.label] = labels.get(node.label, 0) + 1 #labels value = labels value (0 if none) + 1
        # print('recognises', test, 'as', max_image or None, 'label:', label, sep='\n', end='\n\n')
    
    
    

    lab_sum = sum(labels.values())
    cogact_normalised = [(k, v / lab_sum) for k, v in labels.items()]
    top = sorted(cogact_normalised, key=lambda x: -x[1])
    for x in top:
        print('%s (prob = %s)' % (''.join(cogact.nodes[x[0]].image), round(x[1], 2)))
    winner = ''.join(cogact.nodes[top[0][0]].image) if len(top) > 0 else None
    print('correct:', winner == correct_label)
    
    print('final labels scores', labels)
    print('ended in', time.time() - t_start, 'sec')

    print('-------- MAX FREQ METHOD --------\n')
    t_start = time.time()

    labels_full = {}  #scores for all labels
    for test in tests:
        labels = {}
        max_freq = 0
        max_freq_image = None
        label = None
        for offset in range(len(test) - 1):
            node = cogact.visual.recognise(test[offset:])
            if node.label:
                freq = labels.get(node.label, 0) + 1
                labels[node.label] = freq
                if freq > max_freq:
                    max_freq = freq
                    max_freq_image = node.image
                    label = node.label
        #print('recognises', test, 'as', max_freq_image, 'labels:', labels, sep='\n', end='\n\n')
        if label:
            labels_full[label] = labels_full.get(label, 0) + 1
    print('final labels scores', labels_full)

    lab_sum = sum(labels_full.values())
    cogact_normalised = [(k, v / lab_sum) for k, v in labels_full.items()]
    top = sorted(cogact_normalised, key=lambda x: -x[1])
    for x in top:
        print('%s (prob = %s)' % (''.join(cogact.nodes[x[0]].image), round(x[1], 2)))
    winnerF = ''.join(cogact.nodes[top[0][0]].image) if len(top) > 0 else None
    print('correct:', winnerF == correct_label)
    print('ended in', time.time() - t_start, 'sec')
    return winner == correct_label # winner =return winner of maxImage, winnerF = return winner of maxFreq


def cat(folder, get_patterns): #categ per folder
    correct_count = 0
    total_count = 0
    for label in os.listdir(folder):
        p = os.path.join(folder, label)
        if os.path.isdir(p):
            for file in os.listdir(p):
                total_count += 1
                correct_count += cat_file(  #use cat_file function to categorise
                    file=os.path.join(p, file),
                    get_patterns=get_patterns,
                    correct_label=label
                )
    print('-' * 70)
    print('TOTAL CORRECT:', correct_count, '/', total_count)


def cat_poets(folder, sep): #categorise WITHOUT using similarity links
    return cat(folder, lambda text: get_sentences(text, sep))

cat_poets(test_folder, sep_number)





# ## Save / Load State =====================================================================

# In[31]:


#solution to windows problem "pickle esxceeded recursion depth"
sys.setrecursionlimit(10000)


# In[30]:


#SAVE TREE STATE
#with open('CogAct_pA.pickle', 'wb') as f: #wb - write binary

with open(pickle_save, 'wb') as f: #wb - write binary
    pickle.dump(cogact, f)
    f.close()
#with open('Bea_CogAct1.pickle', 'wb') as f:
#    try:
#        pickle.dump(cogact, f)  #wb - write binary
#    except EOFError:
#        pass

    
    